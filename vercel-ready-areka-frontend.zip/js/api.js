const API_BASE = window.location.origin.includes('localhost') ? 'http://localhost:3000/api' : '/api';

class API {
  constructor() {
    this.token = localStorage.getItem('token') || null;
  }

  setToken(token) {
    this.token = token;
    localStorage.setItem('token', token);
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
  }

  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }
    return headers;
  }

  async request(method, endpoint, body = null, isFormData = false) {
    const url = `${API_BASE}${endpoint}`;
    const options = {
      method,
      headers: isFormData ? { 'Authorization': this.token ? `Bearer ${this.token}` : '' } : this.getHeaders()
    };
    if (body && !isFormData) options.body = JSON.stringify(body);
    if (body && isFormData) options.body = body;

    try {
      const response = await fetch(url, options);
      const data = await response.json().catch(() => ({}));
      
      if (response.status === 401 && data.message && data.message.includes('expired')) {
        await this.refreshToken();
        return this.request(method, endpoint, body, isFormData);
      }
      
      if (!response.ok) {
        throw new Error(data.message || `HTTP ${response.status}`);
      }
      return data;
    } catch (error) {
      throw error;
    }
  }

  async refreshToken() {
    const refresh = localStorage.getItem('refreshToken');
    if (!refresh) { auth.logout(); return; }
    try {
      const data = await this.request('POST', '/auth/refresh', { refreshToken: refresh });
      if (data.success) this.setToken(data.token);
    } catch (e) { auth.logout(); }
  }

  get(endpoint) { return this.request('GET', endpoint); }
  post(endpoint, body) { return this.request('POST', endpoint, body); }
  put(endpoint, body) { return this.request('PUT', endpoint, body); }
  delete(endpoint) { return this.request('DELETE', endpoint); }
}

const api = new API();
