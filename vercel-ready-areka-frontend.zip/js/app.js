const app = {
  currentPage: 'dashboard',
  theme: localStorage.getItem('theme') || 'light',
  
  init() {
    document.documentElement.setAttribute('data-theme', this.theme);
    this.renderAuthForm('login');
    if (auth.isLoggedIn()) {
      this.showApp();
    } else {
      this.showAuth('login');
    }
    
    // Handle back button on mobile
    window.addEventListener('popstate', () => {
      const page = location.hash.replace('#', '') || 'dashboard';
      this.navigate(page, false);
    });
  },

  showAuth(mode) {
    document.getElementById('auth-screen').classList.add('active');
    document.getElementById('app-screen').classList.remove('active');
    this.renderAuthForm(mode);
  },

  showApp() {
    document.getElementById('auth-screen').classList.remove('active');
    document.getElementById('app-screen').classList.add('active');
    this.updateMiniProfile();
    this.navigate('dashboard');
    if (auth.isLoggedIn()) chatManager.connect();
  },

  renderAuthForm(mode) {
    const container = document.getElementById('auth-form-container');
    if (mode === 'login') {
      container.innerHTML = `
        <form onsubmit="event.preventDefault(); auth.login(this.email.value, this.password.value).then(ok => { if(ok) this.reset(); })">
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@school.edu" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="••••••••" required minlength="6">
          </div>
          <button type="submit" class="btn btn-primary">Sign In</button>
        </form>
      `;
    } else {
      container.innerHTML = `
        <form onsubmit="event.preventDefault(); auth.register(this.email.value, this.password.value, this.full_name.value, this.section.value).then(ok => { if(ok) this.reset(); })">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" placeholder="Your full name" required>
          </div>
          <div class="form-group">
            <label>Section</label>
            <select name="section">
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
              <option value="D">Section D</option>
            </select>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="you@school.edu" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Min 6 characters" required minlength="6">
          </div>
          <button type="submit" class="btn btn-primary">Join the Union</button>
        </form>
      `;
    }
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.auth-tab:nth-child(${mode === 'login' ? 1 : 2})`).classList.add('active');
  },

  switchAuthTab(mode) {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.auth-tab:nth-child(${mode === 'login' ? 1 : 2})`).classList.add('active');
    this.renderAuthForm(mode);
  },

  navigate(page, pushState = true) {
    this.currentPage = page;
    if (pushState) history.pushState(null, null, `#${page}`);
    
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navItem = document.querySelector(`.nav-item[data-page="${page}"]`);
    if (navItem) navItem.classList.add('active');
    
    const pageTitle = document.getElementById('page-title');
    const pageContent = document.getElementById('page-content');
    
    switch(page) {
      case 'dashboard': 
        pageTitle.textContent = 'Dashboard'; 
        this.renderDashboard(pageContent); 
        break;
      case 'chat': 
        pageTitle.textContent = 'Chat Rooms'; 
        chatManager.render(pageContent); 
        break;
      case 'courses': 
        pageTitle.textContent = 'Courses & Materials'; 
        coursesManager.render(pageContent); 
        break;
      case 'quizzes': 
        pageTitle.textContent = 'Question Templates'; 
        quizzesManager.render(pageContent); 
        break;
      case 'announcements': 
        pageTitle.textContent = 'Union Announcements'; 
        this.renderAnnouncements(pageContent); 
        break;
      case 'profile': 
        pageTitle.textContent = 'My Profile'; 
        this.renderProfile(pageContent); 
        break;
      default: 
        pageTitle.textContent = 'Dashboard'; 
        this.renderDashboard(pageContent);
    }
    this.closeSidebar();
  },

  async renderDashboard(container) {
    try {
      const [annRes, coursesRes, matsRes] = await Promise.all([
        api.get('/announcements').catch(() => ({ announcements: [] })),
        api.get('/courses').catch(() => ({ courses: [] })),
        api.get('/materials?limit=5&status=approved').catch(() => ({ materials: [] }))
      ]);

      const announcements = annRes.announcements || [];
      const courses = coursesRes.courses || [];
      const materials = matsRes.materials || [];
      
      const unreadCount = await api.get('/chat/rooms').then(r => {
        const rooms = r.rooms || [];
        return rooms.reduce((sum, r) => sum + (r.unread_count || 0), 0);
      }).catch(() => 0);
      document.getElementById('chat-badge').textContent = unreadCount > 0 ? unreadCount : '';

      container.innerHTML = `
        <div class="stats-row">
          <div class="stat-card">
            <div class="stat-label">Active Courses</div>
            <div class="stat-value">${courses.length}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Learning Materials</div>
            <div class="stat-value">${materials.length}</div>
            <div class="stat-change">📚 Grade 10 Only</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Unread Messages</div>
            <div class="stat-value">${unreadCount}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Union Status</div>
            <div class="stat-value">🟢</div>
            <div class="stat-change">Active</div>
          </div>
        </div>

        <div class="section-title">📢 Latest Union Announcements</div>
        ${announcements.slice(0, 3).map(a => `
          <div class="announcement-card ${a.priority} ${a.is_pinned ? 'pinned' : ''}">
            <div class="announcement-header">
              <div class="announcement-title">${a.is_pinned ? '📌 ' : ''}${this.escapeHtml(a.title)}</div>
              <div class="announcement-priority ${a.priority}">${a.priority}</div>
            </div>
            <div class="announcement-body">${this.escapeHtml(a.body)}</div>
            <div class="announcement-meta">By ${this.escapeHtml(a.author_name)} • ${this.formatDate(a.created_at)}</div>
          </div>
        `).join('') || '<p style="color:var(--text-secondary)">No announcements yet.</p>'}

        <div class="section-title" style="margin-top:2rem">📚 Your Courses</div>
        <div class="course-list">
          ${courses.slice(0, 4).map(c => `
            <div class="course-card" onclick="app.navigate('courses')">
              <div class="course-cover">
                <div class="course-code">${c.code}</div>
                📖
              </div>
              <div class="course-body">
                <div class="course-title">${this.escapeHtml(c.title)}</div>
                <div class="course-desc">${this.escapeHtml(c.description || 'Grade 10 course materials and discussions.')}</div>
              </div>
            </div>
          `).join('') || '<p style="color:var(--text-secondary)">No courses available yet.</p>'}
        </div>
      `;
    } catch (e) {
      container.innerHTML = `<div class="card"><p>Error loading dashboard. Please refresh.</p></div>`;
    }
  },

  async renderAnnouncements(container) {
    try {
      const data = await api.get('/announcements');
      const announcements = data.announcements || [];
      
      container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem;">
          <h2 style="font-size:1.25rem; font-weight:600;">Union Announcements</h2>
          ${auth.canModerate() ? `<button class="btn btn-primary btn-sm" onclick="app.showCreateAnnouncement()">+ New Announcement</button>` : ''}
        </div>
        ${announcements.map(a => `
          <div class="announcement-card ${a.priority} ${a.is_pinned ? 'pinned' : ''}">
            <div class="announcement-header">
              <div class="announcement-title">${a.is_pinned ? '📌 ' : ''}${this.escapeHtml(a.title)}</div>
              <div class="announcement-priority ${a.priority}">${a.priority}</div>
            </div>
            <div class="announcement-body">${this.escapeHtml(a.body)}</div>
            <div class="announcement-meta">By ${this.escapeHtml(a.author_name)} • ${this.formatDate(a.created_at)}</div>
          </div>
        `).join('') || '<p style="color:var(--text-secondary)">No announcements yet.</p>'}
      `;
    } catch (e) {
      container.innerHTML = `<p style="color:var(--text-secondary)">Failed to load announcements.</p>`;
    }
  },

  async renderProfile(container) {
    const user = auth.getUser();
    if (!user) { auth.logout(); return; }
    
    try {
      const data = await api.get('/auth/profile');
      const profile = data.user || user;
      
      container.innerHTML = `
        <div class="profile-card">
          <div class="profile-header">
            <div class="profile-avatar">${profile.avatar_url ? `<img src="${profile.avatar_url}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">` : '👤'}</div>
          </div>
          <div class="profile-body">
            <div class="profile-name">${this.escapeHtml(profile.full_name)}</div>
            <div class="profile-role">${profile.role}</div>
            <div style="margin-top:1.5rem; display:grid; gap:1rem;">
              <div class="form-group">
                <label>Email</label>
                <input type="text" value="${this.escapeHtml(profile.email)}" disabled>
              </div>
              <div class="form-group">
                <label>Section</label>
                <input type="text" value="${this.escapeHtml(profile.section || 'Not set')}" disabled>
              </div>
              <div class="form-group">
                <label>Grade Level</label>
                <input type="text" value="Grade ${profile.grade_level}" disabled>
              </div>
              <div class="form-group">
                <label>Member Since</label>
                <input type="text" value="${this.formatDate(profile.created_at)}" disabled>
              </div>
            </div>
          </div>
        </div>
      `;
    } catch (e) {
      container.innerHTML = `<p>Error loading profile.</p>`;
    }
  },

  showCreateAnnouncement() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'create-announcement-modal';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <h3>New Union Announcement</h3>
          <button onclick="document.getElementById('create-announcement-modal').remove()">✕</button>
        </div>
        <form onsubmit="event.preventDefault(); app.submitAnnouncement(this)">
          <div class="modal-body">
            <div class="form-group">
              <label>Title</label>
              <input type="text" name="title" required placeholder="Announcement title">
            </div>
            <div class="form-group">
              <label>Body</label>
              <textarea name="body" rows="5" required placeholder="Write the full announcement..."></textarea>
            </div>
            <div class="form-group">
              <label>Priority</label>
              <select name="priority">
                <option value="normal">Normal</option>
                <option value="urgent">Urgent</option>
                <option value="low">Low</option>
              </select>
            </div>
            <div class="form-group">
              <label><input type="checkbox" name="pinned"> Pin to top</label>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('create-announcement-modal').remove()">Cancel</button>
            <button type="submit" class="btn btn-primary btn-sm">Post Announcement</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);
  },

  async submitAnnouncement(form) {
    try {
      app.showLoading(true);
      const data = await api.post('/announcements', {
        title: form.title.value,
        body: form.body.value,
        priority: form.priority.value,
        is_pinned: form.pinned.checked
      });
      if (data.success) {
        app.showToast('Announcement posted!', 'success');
        document.getElementById('create-announcement-modal').remove();
        this.navigate('announcements');
      }
    } catch (e) {
      app.showToast(e.message, 'error');
    } finally {
      app.showLoading(false);
    }
  },

  updateMiniProfile() {
    const user = auth.getUser();
    if (!user) return;
    document.getElementById('mini-name').textContent = user.full_name;
    document.getElementById('mini-role').textContent = user.role.replace('_', ' ');
    document.getElementById('mini-avatar').textContent = user.avatar_url ? '👤' : user.full_name.charAt(0).toUpperCase();
  },

  toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
  },
  closeSidebar() { document.getElementById('sidebar').classList.remove('open'); },
  
  toggleTheme() {
    this.theme = this.theme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.theme);
    localStorage.setItem('theme', this.theme);
  },

  showNotifications() { document.getElementById('notif-panel').classList.remove('hidden'); },
  hideNotifications() { document.getElementById('notif-panel').classList.add('hidden'); },
  
  showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
  },

  showLoading(show) {
    document.getElementById('loading').classList.toggle('hidden', !show);
  },

  escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  },

  formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }
};

// Initialize app on load
window.addEventListener('DOMContentLoaded', () => app.init());
