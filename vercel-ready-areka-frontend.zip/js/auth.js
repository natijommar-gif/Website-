class AuthManager {
  constructor() {
    this.user = null;
    this.init();
  }

  init() {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        this.user = JSON.parse(savedUser);
        api.setToken(localStorage.getItem('token'));
      } catch (e) { this.logout(); }
    }
  }

  async login(email, password) {
    try {
      app.showLoading(true);
      const data = await api.post('/auth/login', { email, password });
      if (data.success) {
        api.setToken(data.token);
        localStorage.setItem('refreshToken', data.refreshToken);
        localStorage.setItem('user', JSON.stringify(data.user));
        this.user = data.user;
        app.showToast('Welcome back, ' + data.user.full_name + '!', 'success');
        app.showApp();
        return true;
      }
    } catch (error) {
      app.showToast(error.message || 'Login failed', 'error');
      return false;
    } finally {
      app.showLoading(false);
    }
  }

  async register(email, password, fullName, section) {
    try {
      app.showLoading(true);
      const data = await api.post('/auth/register', { email, password, full_name: fullName, section });
      if (data.success) {
        app.showToast('Registration successful! Please sign in.', 'success');
        app.showAuth('login');
        return true;
      }
    } catch (error) {
      app.showToast(error.message || 'Registration failed', 'error');
      return false;
    } finally {
      app.showLoading(false);
    }
  }

  logout() {
    api.clearToken();
    this.user = null;
    if (chatManager) chatManager.disconnect();
    app.showAuth('login');
    app.showToast('You have been logged out.', 'warning');
  }

  isLoggedIn() {
    return !!this.user && !!localStorage.getItem('token');
  }

  getUser() { return this.user; }
  isAdmin() { return this.user?.role === 'admin'; }
  isUnion() { return this.user?.role === 'union_leader'; }
  isContributor() { return this.user?.role === 'contributor'; }
  canModerate() { return this.isAdmin() || this.isUnion(); }
}

const auth = new AuthManager();
