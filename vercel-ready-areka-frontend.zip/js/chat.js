class ChatManager {
  constructor() {
    this.socket = null;
    this.currentRoom = null;
    this.rooms = [];
    this.messages = {};
    this.typingTimeout = null;
  }

  connect() {
    if (this.socket) return;
    const token = localStorage.getItem('token');
    if (!token) return;

    this.socket = io({ auth: { token } });

    this.socket.on('connect', () => {
      console.log('Socket connected');
    });

    this.socket.on('disconnect', () => {
      console.log('Socket disconnected');
    });

    this.socket.on('new_message', (msg) => {
      if (msg.room_id === this.currentRoom) {
        this.appendMessage(msg);
        this.scrollToBottom();
      }
      this.updateRoomPreview(msg.room_id, msg.content);
    });

    this.socket.on('user_online', (data) => {
      app.showToast(`${data.userName} is online`, 'info');
    });

    this.socket.on('typing', (data) => {
      if (data.roomId === this.currentRoom) {
        this.showTyping(data.userName);
      }
    });

    this.socket.on('error_message', (data) => {
      app.showToast(data.message, 'error');
    });

    this.socket.on('notification', (notif) => {
      this.addNotification(notif);
    });
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
  }

  async render(container) {
    this.container = container;
    container.innerHTML = `
      <div class="chat-layout">
        <div class="chat-sidebar" id="chat-sidebar">
          <div class="chat-sidebar-header">
            <h3>Chat Rooms</h3>
            ${auth.canModerate() ? `<button class="btn btn-sm btn-primary" onclick="chatManager.showCreateRoom()">+ Room</button>` : ''}
          </div>
          <div class="chat-rooms-list" id="chat-rooms-list"></div>
        </div>
        <div class="chat-main" id="chat-main">
          <div class="chat-empty-state">
            <div class="chat-empty-state-icon">💬</div>
            <h3>Select a room to start chatting</h3>
            <p>Connect with your Grade 10 classmates</p>
          </div>
        </div>
      </div>
    `;
    await this.loadRooms();
  }

  async loadRooms() {
    try {
      const data = await api.get('/chat/rooms');
      this.rooms = data.rooms || [];
      this.renderRoomsList();
    } catch (e) {
      app.showToast('Failed to load chat rooms', 'error');
    }
  }

  renderRoomsList() {
    const list = document.getElementById('chat-rooms-list');
    if (!list) return;
    list.innerHTML = this.rooms.map(r => `
      <div class="chat-room-item ${r.id === this.currentRoom ? 'active' : ''}" onclick="chatManager.openRoom(${r.id})">
        <div class="chat-room-avatar">${r.type === 'channel' ? '📢' : r.type === 'direct' ? '👤' : '👥'}</div>
        <div class="chat-room-info">
          <div class="chat-room-name">${app.escapeHtml(r.name)}</div>
          <div class="chat-room-preview" id="preview-${r.id}">${r.type === 'channel' ? 'Channel' : r.type === 'direct' ? 'Direct Message' : 'Group'}</div>
        </div>
        <div class="chat-room-meta">
          ${r.unread_count > 0 ? `<div class="chat-room-badge">${r.unread_count}</div>` : ''}
        </div>
      </div>
    `).join('');
  }

  async openRoom(roomId) {
    this.currentRoom = roomId;
    this.renderRoomsList();
    
    const room = this.rooms.find(r => r.id === roomId);
    const main = document.getElementById('chat-main');
    
    if (window.innerWidth <= 1024) {
      document.getElementById('chat-sidebar').classList.add('hidden-mobile');
      main.classList.add('active');
    }

    main.innerHTML = `
      <div class="chat-header">
        <button class="chat-header-back" onclick="chatManager.closeMobileRoom()">←</button>
        <div class="chat-room-avatar" style="width:40px;height:40px;font-size:1.125rem;">${room.type === 'channel' ? '📢' : '👥'}</div>
        <div>
          <div style="font-weight:600;font-size:0.95rem;">${app.escapeHtml(room.name)}</div>
          <div style="font-size:0.75rem;color:var(--text-muted);">${room.type === 'channel' ? 'Channel' : 'Group'}</div>
        </div>
      </div>
      <div class="chat-messages" id="chat-messages"></div>
      <div class="chat-typing" id="chat-typing"></div>
      <div class="chat-input-area">
        <button class="chat-attach-btn" title="Attach file (coming soon)">📎</button>
        <textarea class="chat-input" id="chat-input" rows="1" placeholder="Type a message..." onkeydown="chatManager.handleInputKey(event)"></textarea>
        <button class="chat-send-btn" onclick="chatManager.sendMessage()">➤</button>
      </div>
    `;

    if (this.socket) this.socket.emit('join_room', roomId);
    
    try {
      const data = await api.get(`/chat/rooms/${roomId}/messages?limit=50`);
      const msgs = data.messages || [];
      const chatMessages = document.getElementById('chat-messages');
      chatMessages.innerHTML = '';
      msgs.forEach(m => this.appendMessage(m));
      this.scrollToBottom();
      api.post(`/chat/rooms/${roomId}/read`).catch(() => {});
    } catch (e) {
      app.showToast('Failed to load messages', 'error');
    }
  }

  appendMessage(msg) {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    const isMe = msg.sender_id === auth.getUser()?.id;
    const div = document.createElement('div');
    div.className = `chat-message ${isMe ? 'sent' : 'received'}`;
    div.innerHTML = `
      ${!isMe ? `<div class="chat-message-sender">${app.escapeHtml(msg.sender_name || 'Unknown')}</div>` : ''}
      <div>${app.escapeHtml(msg.content)}</div>
      <div class="chat-message-time">${new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
    `;
    container.appendChild(div);
  }

  handleInputKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.sendMessage();
    }
    if (this.socket && this.currentRoom) {
      this.socket.emit('typing', { roomId: this.currentRoom, isTyping: true });
      clearTimeout(this.typingTimeout);
      this.typingTimeout = setTimeout(() => {
        this.socket.emit('typing', { roomId: this.currentRoom, isTyping: false });
      }, 2000);
    }
  }

  sendMessage() {
    const input = document.getElementById('chat-input');
    const content = input?.value?.trim();
    if (!content || !this.currentRoom || !this.socket) return;
    this.socket.emit('send_message', { roomId: this.currentRoom, content, message_type: 'text' });
    input.value = '';
    input.style.height = 'auto';
  }

  showTyping(name) {
    const el = document.getElementById('chat-typing');
    if (!el) return;
    el.textContent = `${name} is typing...`;
    setTimeout(() => { if (el) el.textContent = ''; }, 3000);
  }

  scrollToBottom() {
    const container = document.getElementById('chat-messages');
    if (container) container.scrollTop = container.scrollHeight;
  }

  updateRoomPreview(roomId, content) {
    const preview = document.getElementById(`preview-${roomId}`);
    if (preview) preview.textContent = content.substring(0, 30) + (content.length > 30 ? '...' : '');
  }

  closeMobileRoom() {
    document.getElementById('chat-sidebar').classList.remove('hidden-mobile');
    document.getElementById('chat-main').classList.remove('active');
    this.currentRoom = null;
  }

  addNotification(notif) {
    const list = document.getElementById('notif-list');
    const empty = list.querySelector('.notif-empty');
    if (empty) empty.remove();
    const item = document.createElement('div');
    item.className = 'notif-item unread';
    item.innerHTML = `
      <div class="notif-title">${app.escapeHtml(notif.title)}</div>
      <div class="notif-body">${app.escapeHtml(notif.content)}</div>
      <div class="notif-time">${new Date().toLocaleTimeString()}</div>
    `;
    list.prepend(item);
  }

  showCreateRoom() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'create-room-modal';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-header"><h3>Create Chat Room</h3><button onclick="document.getElementById('create-room-modal').remove()">✕</button></div>
        <form onsubmit="event.preventDefault(); chatManager.createRoom(this)">
          <div class="modal-body">
            <div class="form-group"><label>Room Name</label><input name="name" required placeholder="e.g. Math Study Group"></div>
            <div class="form-group"><label>Type</label>
              <select name="type">
                <option value="channel">Channel (broadcast)</option>
                <option value="group">Group Chat</option>
              </select>
            </div>
            <div class="form-group"><label>Link to Course (optional)</label>
              <select name="course_id"><option value="">None</option></select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('create-room-modal').remove()">Cancel</button>
            <button type="submit" class="btn btn-primary btn-sm">Create Room</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);
    // Load courses for dropdown
    api.get('/courses').then(d => {
      const select = modal.querySelector('select[name="course_id"]');
      select.innerHTML = '<option value="">None</option>' + (d.courses || []).map(c => `<option value="${c.id}">${app.escapeHtml(c.title)}</option>`).join('');
    });
  }

  async createRoom(form) {
    try {
      app.showLoading(true);
      const data = await api.post('/chat/rooms', {
        name: form.name.value,
        type: form.type.value,
        course_id: form.course_id.value || null
      });
      if (data.success) {
        app.showToast('Room created!', 'success');
        document.getElementById('create-room-modal').remove();
        await this.loadRooms();
      }
    } catch (e) {
      app.showToast(e.message, 'error');
    } finally {
      app.showLoading(false);
    }
  }
}

const chatManager = new ChatManager();
