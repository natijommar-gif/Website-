class CoursesManager {
  constructor() {
    this.courses = [];
    this.materials = [];
  }

  async render(container) {
    this.container = container;
    await this.loadCourses();
    this.renderList();
  }

  async loadCourses() {
    try {
      const data = await api.get('/courses');
      this.courses = data.courses || [];
    } catch (e) {
      app.showToast('Failed to load courses', 'error');
    }
  }

  renderList() {
    this.container.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
        <div>
          <h2 style="font-size:1.25rem; font-weight:600;">Courses & Materials</h2>
          <p style="color:var(--text-secondary); font-size:0.875rem; margin-top:0.25rem;">All content is curated by Grade 10 students for Grade 10 students.</p>
        </div>
        <div style="display:flex; gap:0.5rem;">
          <button class="btn btn-sm btn-outline" onclick="coursesManager.filterType='all'; coursesManager.renderList()">All</button>
          <button class="btn btn-sm btn-outline" onclick="coursesManager.filterType='pdf'; coursesManager.renderList()">📄 PDFs</button>
          <button class="btn btn-sm btn-outline" onclick="coursesManager.filterType='video'; coursesManager.renderList()">🎥 Videos</button>
          <button class="btn btn-sm btn-outline" onclick="coursesManager.filterType='audio'; coursesManager.renderList()">🎧 Audio</button>
          <button class="btn btn-sm btn-outline" onclick="coursesManager.filterType='image'; coursesManager.renderList()">🖼️ Images</button>
        </div>
      </div>
      <div class="course-list">
        ${this.courses.map(c => `
          <div class="course-card" onclick="coursesManager.showCourse(${c.id})">
            <div class="course-cover" style="background: linear-gradient(135deg, ${this.stringToColor(c.code)}, ${this.stringToColor(c.code + '2')});">
              <div class="course-code">${c.code}</div>
              ${this.courseEmoji(c.code)}
            </div>
            <div class="course-body">
              <div class="course-title">${app.escapeHtml(c.title)}</div>
              <div class="course-desc">${app.escapeHtml(c.description || 'Grade 10 materials and discussions.')}</div>
              <div class="course-stats">
                <span>${c.material_stats?.find(s => s.file_type === 'pdf')?.count || 0} PDFs</span>
                <span>${c.material_stats?.find(s => s.file_type === 'video')?.count || 0} Videos</span>
                <span>${c.material_stats?.find(s => s.file_type === 'audio')?.count || 0} Audio</span>
                <span>${c.material_stats?.find(s => s.file_type === 'image')?.count || 0} Images</span>
              </div>
            </div>
          </div>
        `).join('') || '<p style="color:var(--text-secondary)">No courses available yet.</p>'}
      </div>
    `;
  }

  async showCourse(courseId) {
    const course = this.courses.find(c => c.id === courseId);
    if (!course) return;

    this.container.innerHTML = `
      <div style="margin-bottom:1.5rem;">
        <button class="btn btn-sm btn-secondary" onclick="coursesManager.renderList()">← Back to Courses</button>
        <h2 style="font-size:1.5rem; font-weight:700; margin-top:1rem;">${app.escapeHtml(course.title)}</h2>
        <p style="color:var(--text-secondary); margin-top:0.25rem;">${app.escapeHtml(course.description || '')}</p>
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
        <h3>📂 Materials</h3>
        <button class="btn btn-sm btn-primary" onclick="coursesManager.showUpload(${courseId})">+ Upload Material</button>
      </div>
      <div id="materials-list" class="materials-list">Loading...</div>
    `;
    await this.loadMaterials(courseId);
    this.renderMaterials(courseId);
  }

  async loadMaterials(courseId) {
    try {
      const data = await api.get(`/materials?course_id=${courseId}&status=approved`);
      this.materials = data.materials || [];
    } catch (e) {
      app.showToast('Failed to load materials', 'error');
    }
  }

  renderMaterials(courseId) {
    const list = document.getElementById('materials-list');
    if (!list) return;
    const filtered = this.filterType && this.filterType !== 'all' 
      ? this.materials.filter(m => m.file_type === this.filterType) 
      : this.materials;

    list.innerHTML = filtered.map(m => `
      <div class="material-item">
        <div class="material-icon">${this.fileIcon(m.file_type)}</div>
        <div class="material-info">
          <div class="material-title">${app.escapeHtml(m.title)}</div>
          <div class="material-meta">
            ${m.file_type.toUpperCase()} • ${this.formatBytes(m.file_size)} • By ${app.escapeHtml(m.uploader_name)} • ${app.formatDate(m.created_at)}
          </div>
        </div>
        <div class="material-actions">
          <a href="/api/materials/${m.id}/download" class="btn btn-sm btn-primary" target="_blank">Download</a>
          ${m.file_type === 'image' ? `<a href="/api/materials/${m.id}/download" class="btn btn-sm btn-outline" target="_blank">View</a>` : ''}
        </div>
      </div>
    `).join('') || '<p style="color:var(--text-secondary); padding:1rem;">No materials in this category yet. Be the first to upload!</p>';
  }

  showUpload(courseId) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'upload-modal';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-header"><h3>Upload Material</h3><button onclick="document.getElementById('upload-modal').remove()">✕</button></div>
        <form id="upload-form" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="form-group"><label>Title</label><input type="text" name="title" required placeholder="e.g. Chapter 3 Notes"></div>
            <div class="form-group"><label>Description</label><textarea name="description" rows="2" placeholder="Brief description..."></textarea></div>
            <div class="form-group">
              <label>Type</label>
              <select name="file_type" required>
                <option value="pdf">PDF (Notes, Books, Exams)</option>
                <option value="video">Video (Lessons, Explanations)</option>
                <option value="audio">Audio (Podcasts, Oral)</option>
                <option value="image">Image (Diagrams, Scans)</option>
              </select>
            </div>
            <div class="form-group">
              <label>File</label>
              <div class="material-upload-zone" id="drop-zone" onclick="document.getElementById('file-input').click()">
                <div style="font-size:2rem; margin-bottom:0.5rem;">📤</div>
                <div style="font-weight:600; margin-bottom:0.25rem;">Click to upload or drag file here</div>
                <div style="font-size:0.875rem; color:var(--text-secondary);">Max: PDF 20MB, Video 100MB, Audio 20MB, Image 5MB</div>
              </div>
              <input type="file" id="file-input" name="file" required style="display:none;" onchange="coursesManager.handleFileSelect(this)">
              <div id="selected-file" style="margin-top:0.75rem; font-size:0.875rem; color:var(--text-secondary);"></div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('upload-modal').remove()">Cancel</button>
            <button type="button" class="btn btn-primary btn-sm" onclick="coursesManager.submitUpload(${courseId})">Upload</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    // Drag & drop
    const zone = document.getElementById('drop-zone');
    zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
    zone.addEventListener('drop', e => {
      e.preventDefault(); zone.classList.remove('dragover');
      const files = e.dataTransfer.files;
      if (files.length) {
        document.getElementById('file-input').files = files;
        coursesManager.handleFileSelect(document.getElementById('file-input'));
      }
    });
  }

  handleFileSelect(input) {
    const file = input.files[0];
    if (!file) return;
    document.getElementById('selected-file').textContent = `Selected: ${file.name} (${this.formatBytes(file.size)})`;
  }

  async submitUpload(courseId) {
    const form = document.getElementById('upload-form');
    const formData = new FormData(form);
    formData.append('course_id', courseId);
    try {
      app.showLoading(true);
      const data = await api.request('POST', '/materials/upload', formData, true);
      if (data.success) {
        app.showToast(data.status === 'pending' ? 'Upload submitted for approval!' : 'Upload successful!', 'success');
        document.getElementById('upload-modal').remove();
        await this.loadMaterials(courseId);
        this.renderMaterials(courseId);
      }
    } catch (e) {
      app.showToast(e.message || 'Upload failed', 'error');
    } finally {
      app.showLoading(false);
    }
  }

  fileIcon(type) {
    return { pdf: '📄', video: '🎥', audio: '🎧', image: '🖼️' }[type] || '📎';
  }

  courseEmoji(code) {
    if (code.includes('MATH')) return '🔢';
    if (code.includes('ENG')) return '📖';
    if (code.includes('BIO')) return '🧬';
    if (code.includes('PHY')) return '⚡';
    if (code.includes('CHEM')) return '🧪';
    if (code.includes('CIV')) return '🏛️';
    if (code.includes('HIST')) return '📜';
    if (code.includes('GEO')) return '🌍';
    return '📚';
  }

  stringToColor(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
    const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
    return '#' + '00000'.substring(0, 6 - c.length) + c;
  }

  formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

const coursesManager = new CoursesManager();
