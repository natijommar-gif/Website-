class QuizzesManager {
  constructor() {
    this.quizzes = [];
    this.currentQuiz = null;
    this.currentAttempt = null;
    this.answers = {};
    this.timerInterval = null;
  }

  async render(container) {
    this.container = container;
    await this.loadQuizzes();
    this.renderList();
  }

  async loadQuizzes() {
    try {
      const data = await api.get('/quizzes?published_only=true');
      this.quizzes = data.quizzes || [];
    } catch (e) {
      app.showToast('Failed to load quizzes', 'error');
    }
  }

  renderList() {
    this.container.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;">
        <div>
          <h2 style="font-size:1.25rem; font-weight:600;">Question Templates & Practice</h2>
          <p style="color:var(--text-secondary); font-size:0.875rem; margin-top:0.25rem;">Test your knowledge with student-generated questions.</p>
        </div>
        ${auth.canModerate() || auth.isContributor() ? `<button class="btn btn-sm btn-primary" onclick="quizzesManager.showCreateQuiz()">+ Create Quiz</button>` : ''}
      </div>
      <div id="quizzes-list">
        ${this.quizzes.map(q => `
          <div class="quiz-card">
            <div class="quiz-header">
              <div>
                <div class="quiz-title">${app.escapeHtml(q.title)}</div>
                <div style="font-size:0.875rem; color:var(--text-secondary); margin-top:0.25rem;">${app.escapeHtml(q.course_name || 'General')} • By ${app.escapeHtml(q.creator_name)}</div>
              </div>
              <div class="quiz-badge ${q.is_published ? 'published' : 'draft'}">${q.is_published ? 'Published' : 'Draft'}</div>
            </div>
            <div class="quiz-meta">
              <span>⏱️ ${q.time_limit ? q.time_limit + ' min' : 'No time limit'}</span>
              <span>🎯 Pass: ${q.passing_score}%</span>
              <span>📝 ${q.description ? app.escapeHtml(q.description) : 'Practice quiz for Grade 10 students.'}</span>
            </div>
            <div class="card-actions">
              <button class="btn btn-primary btn-sm" onclick="quizzesManager.startQuiz(${q.id})">Start Quiz</button>
              ${auth.canModerate() ? `<button class="btn btn-outline btn-sm" onclick="quizzesManager.publishQuiz(${q.id})">Publish</button>` : ''}
            </div>
          </div>
        `).join('') || '<p style="color:var(--text-secondary)">No quizzes available yet. Check back soon!</p>'}
      </div>
    `;
  }

  async startQuiz(quizId) {
    try {
      app.showLoading(true);
      const data = await api.get(`/quizzes/${quizId}`);
      this.currentQuiz = data.quiz;
      this.answers = {};
      this.renderQuiz(data.questions);
    } catch (e) {
      app.showToast(e.message || 'Failed to load quiz', 'error');
    } finally {
      app.showLoading(false);
    }
  }

  renderQuiz(questions) {
    const quiz = this.currentQuiz;
    this.container.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.5rem;">
        <div>
          <button class="btn btn-sm btn-secondary" onclick="quizzesManager.renderList()">← Back</button>
          <h2 style="font-size:1.25rem; font-weight:600; margin-top:0.75rem;">${app.escapeHtml(quiz.title)}</h2>
          <p style="color:var(--text-secondary); font-size:0.875rem;">${app.escapeHtml(quiz.description || '')}</p>
        </div>
      </div>
      ${quiz.time_limit ? `<div class="quiz-timer" id="quiz-timer">${quiz.time_limit}:00</div>` : ''}
      <div id="quiz-questions">
        ${questions.map((q, idx) => `
          <div class="quiz-question" data-qid="${q.id}">
            <div class="quiz-question-text">${idx + 1}. ${app.escapeHtml(q.question_text)}</div>
            ${q.image_url ? `<img src="${q.image_url}" style="max-width:100%; border-radius:8px; margin-bottom:1rem; border:1px solid var(--border);">` : ''}
            ${this.renderOptions(q, idx)}
          </div>
        `).join('')}
      </div>
      <div style="margin-top:2rem; text-align:center;">
        <button class="btn btn-primary" style="width:auto; padding:0.875rem 2rem;" onclick="quizzesManager.submitQuiz()">Submit Answers</button>
      </div>
    `;

    if (quiz.time_limit) this.startTimer(quiz.time_limit * 60);
  }

  renderOptions(q, idx) {
    if (q.question_type === 'multiple_choice' && q.options) {
      return `<div class="quiz-options">
        ${q.options.map((opt, i) => `
          <label class="quiz-option" onclick="quizzesManager.selectOption(${q.id}, '${opt}', this)">
            <input type="radio" name="q_${q.id}" value="${opt}" style="display:none;">
            <span>${app.escapeHtml(opt)}</span>
          </label>
        `).join('')}
      </div>`;
    }
    if (q.question_type === 'true_false') {
      return `<div class="quiz-options">
        <label class="quiz-option" onclick="quizzesManager.selectOption(${q.id}, 'true', this)">
          <input type="radio" name="q_${q.id}" value="true" style="display:none;"> True
        </label>
        <label class="quiz-option" onclick="quizzesManager.selectOption(${q.id}, 'false', this)">
          <input type="radio" name="q_${q.id}" value="false" style="display:none;"> False
        </label>
      </div>`;
    }
    if (q.question_type === 'fill_blank' || q.question_type === 'short_answer') {
      return `<div class="form-group" style="margin-top:0.75rem;">
        <input type="text" class="quiz-input" placeholder="Your answer..." onchange="quizzesManager.setAnswer(${q.id}, this.value)">
      </div>`;
    }
    return '<div style="color:var(--text-muted); font-size:0.875rem;">Unsupported question type</div>';
  }

  selectOption(qid, value, el) {
    this.answers[qid] = value;
    const parent = el.closest('.quiz-options');
    parent.querySelectorAll('.quiz-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
  }

  setAnswer(qid, value) {
    this.answers[qid] = value;
  }

  startTimer(seconds) {
    let remaining = seconds;
    const timerEl = document.getElementById('quiz-timer');
    this.timerInterval = setInterval(() => {
      remaining--;
      if (remaining <= 0) {
        clearInterval(this.timerInterval);
        this.submitQuiz();
        return;
      }
      const mins = Math.floor(remaining / 60);
      const secs = remaining % 60;
      if (timerEl) {
        timerEl.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
        if (remaining < 60) timerEl.classList.add('warning');
      }
    }, 1000);
  }

  async submitQuiz() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    const timerEl = document.getElementById('quiz-timer');
    if (timerEl) timerEl.remove();

    try {
      app.showLoading(true);
      const timeSpent = this.currentQuiz.time_limit ? (this.currentQuiz.time_limit * 60) - this.parseTimer(timerEl) : null;
      const data = await api.post(`/quizzes/${this.currentQuiz.id}/attempt`, { 
        answers: this.answers, 
        time_spent: timeSpent 
      });
      this.renderResult(data);
    } catch (e) {
      app.showToast(e.message || 'Submission failed', 'error');
    } finally {
      app.showLoading(false);
    }
  }

  parseTimer(el) {
    if (!el) return null;
    const text = el.textContent;
    const [m, s] = text.split(':').map(Number);
    return m * 60 + s;
  }

  renderResult(data) {
    this.container.innerHTML = `
      <div class="quiz-result">
        <div class="quiz-result-score">${data.percentage}%</div>
        <div class="quiz-result-${data.passed ? 'pass' : 'fail'}">${data.passed ? '✅ You Passed!' : '❌ You Did Not Pass'}</div>
        <div style="color:var(--text-secondary); margin-top:1rem; font-size:1rem;">
          Score: ${data.score} / ${data.max_score}
        </div>
        <div style="margin-top:2rem;">
          <button class="btn btn-primary btn-sm" onclick="quizzesManager.renderList()">Back to Quizzes</button>
          <button class="btn btn-secondary btn-sm" onclick="quizzesManager.startQuiz(${this.currentQuiz.id})">Retake</button>
        </div>
      </div>
    `;
  }

  showCreateQuiz() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'create-quiz-modal';
    modal.innerHTML = `
      <div class="modal" style="max-width:600px;">
        <div class="modal-header"><h3>Create New Quiz</h3><button onclick="document.getElementById('create-quiz-modal').remove()">✕</button></div>
        <form onsubmit="event.preventDefault(); quizzesManager.createQuiz(this)">
          <div class="modal-body">
            <div class="form-group"><label>Title</label><input name="title" required placeholder="e.g. Biology Mid-Term Prep"></div>
            <div class="form-group"><label>Course</label><select name="course_id" id="quiz-course-select"><option value="">General / No specific course</option></select></div>
            <div class="form-group"><label>Description</label><textarea name="description" rows="2" placeholder="What this quiz covers..."></textarea></div>
            <div class="form-group"><label>Time Limit (minutes, optional)</label><input type="number" name="time_limit" min="1" placeholder="Leave blank for no limit"></div>
            <div class="form-group"><label>Passing Score (%)</label><input type="number" name="passing_score" value="70" min="0" max="100"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('create-quiz-modal').remove()">Cancel</button>
            <button type="submit" class="btn btn-primary btn-sm">Create Quiz</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);
    api.get('/courses').then(d => {
      const sel = document.getElementById('quiz-course-select');
      sel.innerHTML = '<option value="">General / No specific course</option>' + (d.courses || []).map(c => `<option value="${c.id}">${app.escapeHtml(c.title)}</option>`).join('');
    });
  }

  async createQuiz(form) {
    try {
      app.showLoading(true);
      const data = await api.post('/quizzes', {
        title: form.title.value,
        course_id: form.course_id.value || null,
        description: form.description.value,
        time_limit: form.time_limit.value ? parseInt(form.time_limit.value) : null,
        passing_score: parseInt(form.passing_score.value)
      });
      if (data.success) {
        app.showToast('Quiz created! Now add questions.', 'success');
        document.getElementById('create-quiz-modal').remove();
        this.showAddQuestions(data.quiz_id);
      }
    } catch (e) {
      app.showToast(e.message, 'error');
    } finally {
      app.showLoading(false);
    }
  }

  showAddQuestions(quizId) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'add-questions-modal';
    modal.innerHTML = `
      <div class="modal" style="max-width:700px;">
        <div class="modal-header"><h3>Add Questions</h3><button onclick="document.getElementById('add-questions-modal').remove(); quizzesManager.renderList()">Done</button></div>
        <div class="modal-body">
          <form id="question-form" onsubmit="event.preventDefault(); quizzesManager.addQuestion(${quizId}, this)">
            <div class="form-group"><label>Question Type</label>
              <select name="question_type" onchange="quizzesManager.updateQuestionForm(this.value)">
                <option value="multiple_choice">Multiple Choice</option>
                <option value="true_false">True / False</option>
                <option value="fill_blank">Fill in the Blank</option>
                <option value="short_answer">Short Answer</option>
              </select>
            </div>
            <div class="form-group"><label>Question Text</label><textarea name="question_text" rows="2" required placeholder="Enter the question..."></textarea></div>
            <div id="question-options-area">
              <div class="form-group"><label>Options (one per line)</label><textarea name="options" rows="4" placeholder="A&#10;B&#10;C&#10;D"></textarea></div>
            </div>
            <div class="form-group"><label>Correct Answer</label><input name="correct_answer" required placeholder="Exact correct answer"></div>
            <div class="form-group"><label>Explanation (optional)</label><textarea name="explanation" rows="2" placeholder="Why this is correct..."></textarea></div>
            <div class="form-group"><label>Points</label><input type="number" name="points" value="1" min="1"></div>
            <button type="submit" class="btn btn-primary btn-sm">Add Question</button>
          </form>
          <div id="added-questions" style="margin-top:1.5rem;"></div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }

  updateQuestionForm(type) {
    const area = document.getElementById('question-options-area');
    if (type === 'multiple_choice') {
      area.innerHTML = `<div class="form-group"><label>Options (one per line)</label><textarea name="options" rows="4" placeholder="A&#10;B&#10;C&#10;D"></textarea></div>`;
    } else if (type === 'true_false') {
      area.innerHTML = `<div class="form-group"><label>Options</label><input value="True / False" disabled style="background:var(--bg-secondary);"></div><input type="hidden" name="options" value='["true", "false"]>'>`;
    } else {
      area.innerHTML = '';
    }
  }

  async addQuestion(quizId, form) {
    try {
      app.showLoading(true);
      const type = form.question_type.value;
      let options = null;
      if (type === 'multiple_choice') {
        options = form.options?.value?.split('\n').filter(o => o.trim()).map(o => o.trim());
      } else if (type === 'true_false') {
        options = ['true', 'false'];
      }
      
      const data = await api.post(`/quizzes/${quizId}/questions`, {
        question_text: form.question_text.value,
        question_type: type,
        options: options,
        correct_answer: form.correct_answer.value,
        explanation: form.explanation.value,
        points: parseInt(form.points.value) || 1
      });
      if (data.success) {
        app.showToast('Question added!', 'success');
        form.reset();
        const list = document.getElementById('added-questions');
        list.innerHTML += `<div style="padding:0.75rem; background:var(--bg-secondary); border-radius:8px; margin-bottom:0.5rem; font-size:0.875rem;">✅ Question added successfully</div>`;
      }
    } catch (e) {
      app.showToast(e.message, 'error');
    } finally {
      app.showLoading(false);
    }
  }

  async publishQuiz(quizId) {
    try {
      const data = await api.put(`/quizzes/${quizId}/publish`);
      if (data.success) {
        app.showToast('Quiz published!', 'success');
        await this.loadQuizzes();
        this.renderList();
      }
    } catch (e) {
      app.showToast(e.message, 'error');
    }
  }
}

const quizzesManager = new QuizzesManager();
